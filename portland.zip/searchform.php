<form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
     <fieldset id="fieldset" class="fieldset">
         <label for="s" class="screen-reader-text">Search for:</label>
         <input type="search" id="s" name="s" placeholder="Enter your query here" required />
         <p>Type in your query and press return</p>
     </fieldset>
</form>